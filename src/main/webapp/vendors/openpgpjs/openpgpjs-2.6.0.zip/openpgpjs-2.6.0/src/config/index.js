/**
 * @see module:config/config
 * @module config
 */

'use strict';

export { default } from './config.js';