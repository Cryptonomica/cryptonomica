describe('Crypto', function () {
  require('./cipher');
  require('./hash');
  require('./random.js');
  require('./crypto.js');
});
