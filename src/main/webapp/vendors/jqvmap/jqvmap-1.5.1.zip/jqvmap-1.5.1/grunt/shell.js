module.exports = {
  lint: {
    command: "node_modules/.bin/eslint src --quiet && echo '\033[0;32m\n✓ All Good\033[0m  ٩(ˊᗜˋ*)و'",
    stdout: false
  }
};
